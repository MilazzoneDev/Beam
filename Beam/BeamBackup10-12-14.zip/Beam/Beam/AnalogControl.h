//
//  AnalogControl.h
//  Beam
//
//  Created by Carl Milazzo on 10/2/14.
//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnalogControl : UIView

@property (nonatomic, assign) CGPoint relativePosition;

@end
