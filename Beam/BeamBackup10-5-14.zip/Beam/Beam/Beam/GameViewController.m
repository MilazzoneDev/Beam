//
//  GameViewController.m
//  Beam
//
//  Created by Carl Milazzo on 9/24/14.
//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import "GameViewController.h"
#import "GameScene.h"
#import "AnalogControl.h"
#import "ButtonControl.h"
#import "OptionsButton.h"
#import "OptionsMenu.h"

//values for buttons
static float const padSide = 128;
static float const padPadding = 10;


@implementation SKScene (Unarchive)

+ (instancetype)unarchiveFromFile:(NSString *)file {
    /* Retrieve scene file path from the application bundle */
    NSString *nodePath = [[NSBundle mainBundle] pathForResource:file ofType:@"sks"];
    /* Unarchive the file to an SKScene object */
    NSData *data = [NSData dataWithContentsOfFile:nodePath
                                          options:NSDataReadingMappedIfSafe
                                            error:nil];
    NSKeyedUnarchiver *arch = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    [arch setClass:self forClassName:@"SKScene"];
    SKScene *scene = [arch decodeObjectForKey:NSKeyedArchiveRootObjectKey];
    [arch finishDecoding];
    
    return scene;
}

@end

@implementation GameViewController
{
    AnalogControl *_analogControl;
    ButtonControl *_buttonControl;
    OptionsButton *_optionControl;
    
    SKView *skView;
    GameScene *_scene;
    OptionsMenu *_options;
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    if (!skView)
    {
        // Configure the view.
        skView = [[SKView alloc] initWithFrame:self.view.bounds];//(SKView *)self.view;
        skView.showsFPS = YES;
        skView.showsNodeCount = YES;
        /* Sprite Kit applies additional optimizations to improve rendering performance */
        skView.ignoresSiblingOrder = YES;
        //skView.showsPhysics = YES;
        
        //sets up the game scene
        [self setUpGameView];
        [self setUpOptions];
        
    }
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (BOOL)shouldAutorotate
{
    return YES;
}

#pragma mark setup options and game scene
-(void)setUpOptions
{
    //-skView.frame.size.width
    _options = [[OptionsMenu alloc] initWithFrame:CGRectMake(padPadding*3, padPadding*3,skView.frame.size.width-(padPadding*6) , skView.frame.size.height-(padPadding*6))];
    _options.hidden = YES;
    [self.view addSubview:_options];
    //slider to change the hue
    [_options addObserver:_scene forKeyPath:@"sliderValue" options:NSKeyValueObservingOptionNew context:nil];
    //button to close the options menu
    [_options addObserver:self forKeyPath:@"donePressed" options:NSKeyValueObservingOptionNew context:nil];
    
}

-(void)setUpGameView
{
    // Create and configure the scene.
    GameScene *scene = [[GameScene alloc]initWithSize:skView.bounds.size];//[GameScene unarchiveFromFile:@"GameScene"];
    scene.scaleMode = SKSceneScaleModeAspectFill;
    // Present the scene.
    [skView presentScene:scene];
    [self.view addSubview:skView];
    
    
    //analog joystick
    _analogControl = [[AnalogControl alloc] initWithFrame:CGRectMake(padPadding, skView.frame.size.height-padPadding-padSide, padSide, padSide)];
    [self.view addSubview:_analogControl];
    //observer to the joystick to control the player
    [_analogControl addObserver:scene forKeyPath:@"relativePosition" options:NSKeyValueObservingOptionNew context:nil];
    
    //button to fire the beam
    _buttonControl = [[ButtonControl alloc] initWithFrame:CGRectMake(skView.frame.size.width-padPadding-padSide, skView.frame.size.height-padPadding-padSide, padSide, padSide)];
    [self.view addSubview:_buttonControl];
    //observer for the game to fire the beam
    [_buttonControl addObserver:scene forKeyPath:@"buttonPressed" options:NSKeyValueObservingOptionNew context:nil];
    
    //options control
    _optionControl = [[OptionsButton alloc]initWithFrame:CGRectMake(skView.frame.size.width-padPadding-(padSide/3), padPadding, padSide/3, padSide/3)];
    [self.view addSubview:_optionControl];
    //button to open options menu
    [_optionControl addObserver:self forKeyPath:@"optionsPressed" options:NSKeyValueObservingOptionNew context:nil];
    
    _scene = scene;
}

#pragma mark key-value-observers for controls
//observers for controls
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    //did we want to open the options menu
    if([keyPath isEqualToString:@"optionsPressed"])
    {
        [self showOptions:YES];
    }
    //did we want to close the options menu
    if([keyPath isEqualToString:@"donePressed"])
    {
        [self showOptions:NO];
    }

}

-(void)showOptions:(BOOL)show
{
    NSLog(@"Toggle Options Menu");
    if(show)
    {
        //_options.frame = CGRectMake(padPadding, padPadding, _options.frame.size.width, _options.frame.size.height);
        _options.hidden = NO;
        [_scene pauseGame];
    }
    else
    {
        //_options.frame = CGRectMake(padPadding, -skView.frame.size.width,skView.frame.size.width-(padPadding*2) , skView.frame.size.height-(padPadding*2));
        _options.hidden = YES;
        [_scene playGame];
    }
}

- (NSUInteger)supportedInterfaceOrientations
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    } else {
        return UIInterfaceOrientationMaskAll;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

-(void)dealloc
{
    if(_scene)
    {
        [_analogControl removeObserver:_scene forKeyPath:@"relativePosition"];
        [_buttonControl removeObserver:_scene forKeyPath:@"buttonPressed"];
        [_optionControl removeObserver:self forKeyPath:@"optionsPressed"];
        [_options removeObserver:_scene forKeyPath:@"sliderValue"];
        [_options removeObserver:self forKeyPath:@"donePressed"];
    }
}

@end
