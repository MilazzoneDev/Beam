//
//  Player.m
//  Beam
//
//  Created by Carl Milazzo on 9/24/14.
//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import "Player.h"


@implementation Player
{
    float color;
    float _playerRadius;
}

-(id)initWithImageNamed:(NSString *)name
{
    if (self = [super initWithImageNamed:name])
    {
        
        
    }
    return self;
}

-(id)initWithRadius:(float)playerRadius
{
    if(self = [super init])
    {
        color = 0;
        _playerRadius = playerRadius;
        //CGSize spriteSize = CGSizeMake(playerRadius * 2, playerRadius * 2);
        _sprite = [SKShapeNode shapeNodeWithCircleOfRadius:playerRadius];
        [_sprite setFillColor:[UIColor colorWithHue:color saturation:1 brightness:1 alpha:1]];
        [_sprite setStrokeColor:[UIColor clearColor]];
        
        [self addChild:_sprite];
        
        _forwardSprite = [SKShapeNode shapeNodeWithCircleOfRadius:5];
        [_forwardSprite setFillColor:[UIColor whiteColor]];
        [_forwardSprite setStrokeColor:[UIColor clearColor]];
        _forwardSprite.position = CGPointMake(playerRadius, 0);
        
        [self addChild:_forwardSprite];
        
        self.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:playerRadius];
        self.physicsBody.allowsRotation = NO;
        self.physicsBody.dynamic = YES;
    }
    
    return self;
}

-(void)redrawCircle
{
    [self removeAllChildren];
    
    color -= .01;
    if(color <= 0)
    {
        color = 1;
    }
    _sprite = [SKShapeNode shapeNodeWithCircleOfRadius:_playerRadius];
    [_sprite setFillColor:[UIColor colorWithHue:color saturation:1 brightness:1 alpha:1]];
    [_sprite setStrokeColor:[UIColor clearColor]];
    [self addChild:_sprite];
    
    _forwardSprite = [SKShapeNode shapeNodeWithCircleOfRadius:5];
    [_forwardSprite setFillColor:[UIColor whiteColor]];
    [_forwardSprite setStrokeColor:[UIColor clearColor]];
    _forwardSprite.position = CGPointMake(_playerRadius, 0);
    
    [self addChild:_forwardSprite];
}

@end
