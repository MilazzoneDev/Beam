//
//  GameViewController.h
//  Beam
//

//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface GameViewController : UIViewController

@end
