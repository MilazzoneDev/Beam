//
//  BeamNode.h
//  Beam
//
//  Created by Carl Milazzo on 10/2/14.
//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface BeamNode : SKSpriteNode

@property (nonatomic, assign) BOOL Active;

-(id)initWithSize:(double)size andHue:(double)hue withDuration:(double)duration andTime:(double)changeTime toDirection:(CGPoint)direction;

-(void)redrawCircle:(float)dt;

-(void)changeVelocity;

@end
