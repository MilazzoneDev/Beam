//
//  GameScene.h
//  Beam
//

//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene :  SKScene<UIAccelerometerDelegate,SKPhysicsContactDelegate>


-(void)pauseGame;
-(void)playGame;

@end
