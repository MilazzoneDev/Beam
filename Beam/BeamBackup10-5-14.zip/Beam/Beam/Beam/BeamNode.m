//
//  BeamNode.m
//  Beam
//
//  Created by Carl Milazzo on 10/2/14.
//  Copyright (c) 2014 Carl Milazzo. All rights reserved.
//

#import "BeamNode.h"
#import "SKTUtils.h"

@implementation BeamNode
{
    //used to track and show lifetime left
    float _saturation;
    //color of the beam
    float _hue;
    //size of each particle
    double _size;
    
    //time until chnage
    double _changeTime;
    //direction to change to
    CGPoint _direction;
}

//init with the size of the particle, the color of the particle, the duration to stay on screen, the time until it changes direction (spread), and the direction to change to (after spread)
//the parent class will set the initial velocity
-(id)initWithSize:(double)size andHue:(double)hue withDuration:(double)duration andTime:(double)changeTime toDirection:(CGPoint)direction
{
    if(self = [super init])
    {
        _saturation = duration;
        _hue = hue;
        _size = size;
        _changeTime = changeTime;
        _direction = direction;

        //create the node
        CGSize spriteSize = CGSizeMake(_size, _size);
        SKShapeNode* sprite = [SKShapeNode shapeNodeWithEllipseOfSize:spriteSize];
        [sprite setFillColor:[UIColor colorWithHue:_hue saturation:_saturation brightness:1 alpha:1]];
        [sprite setStrokeColor:[UIColor clearColor]];
        self.Active = YES;
        //add a physics body to the node
        self.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:_size/2];
        self.physicsBody.restitution = 0.9;
        self.name = @"beamNode";
        //add it to the screen
        [self addChild:sprite];
        
        //set up action to allow the node to change direction (spread)
        SKAction* wait = [SKAction waitForDuration:_changeTime];
        SKAction* changeDirection = [SKAction performSelector:@selector(changeVelocity) onTarget:self];
        [self runAction:[SKAction sequence:@[wait,changeDirection]]];
    }
    
    return self;
}

-(void)redrawCircle:(float)dt
{
    //used to track lifetime
    _saturation -= dt;
    
    //if life left is <= 0 set it to be removed
    if(_saturation <= 0)
    {
        self.Active = NO;
    }
    //if saturation is less then 1 we want to redraw it
    if(_saturation < 1)
    {
        [self removeAllChildren];
        
        CGSize spriteSize = CGSizeMake(_size, _size);
        SKShapeNode* sprite = [SKShapeNode shapeNodeWithEllipseOfSize:spriteSize];
        [sprite setFillColor:[UIColor colorWithHue:_hue saturation:_saturation brightness:1 alpha:1]];
        [sprite setStrokeColor:[UIColor clearColor]];
        [self addChild:sprite];
    
    }
    
}

//used to change direction after spread
-(void)changeVelocity
{
    //what is the old velocity
    CGPoint velocity = CGPointMake([self.physicsBody velocity].dx,[self.physicsBody velocity].dy);
    //grab the speed from the old velocity
    float speed = CGPointLength(velocity);
    //set new velocity with the same speed and the desired direction
    CGPoint newVelocity = CGPointMultiplyScalar(_direction, speed);
    //tell the physicsbody
    [self.physicsBody setVelocity: CGVectorMake(newVelocity.x, newVelocity.y)];
}

@end
